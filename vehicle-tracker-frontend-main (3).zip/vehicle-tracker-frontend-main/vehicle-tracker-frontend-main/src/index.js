// Initialize Leaflet map
const map = L.map('map').setView([51.505, -0.09], 13);

// Add OpenStreetMap tile layer
L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
}).addTo(map);

// Watch for geolocation updates
navigator.geolocation.watchPosition(myLocation, error);

// Declare marker, circle, and zoomed variables
let marker, circle, zoomed;

// Callback function for handling geolocation updates
function myLocation(pos) {
    const { latitude: lat, longitude: lng, accuracy } = pos.coords;

    // Add marker and circle to map
    marker = L.marker([lat, lng]).addTo(map);
    circle = L.circle([lat, lng], { radius: accuracy }).addTo(map);

    // Fit map bounds to circle if not already zoomed
    if (!zoomed) {
        map.fitBounds(circle.getBounds());
        zoomed = true;
    }

    // Set map view to current location
    map.setView([lat, lng]);
}

// Error handling function for geolocation
function error(err) {
    if (err.code === 1) {
        alert("Please allow geolocation access.");
    } else {
        alert("Cannot get current location.");
    }
}

// Function to register a new vehicle
function registerVehicle(make, model, regNumber) {
    axios.post("http://localhost:8080/api/vehicle", { make, model, regNumber }, {
        headers: { 'Content-Type': 'application/json' }
    })
    .then(response => {
        console.log("Vehicle registered:", response.data);
        fetchVehicleData(); // Update vehicle list after registration
    })
    .catch(error => {
        console.error("Error registering vehicle:", error);
    });
}

// Function to fetch and display registered vehicles
function fetchVehicleData() {
    axios.get("http://localhost:8080/api/vehicle/get-vehicles")
    .then(response => {
        let vehicleHtml = "";

        response.data.forEach(vehicle => {
            vehicleHtml += `
                <div>
                    Make: ${vehicle.make},
                    Model: ${vehicle.model}, 
                    Registration Number: ${vehicle.regNumber}
                </div>`;
        });

        // Update vehicles list on the webpage
        document.getElementById("vehicles-list").innerHTML = vehicleHtml;
    })
    .catch(error => {
        console.error("Error fetching vehicle data:", error);
    });
}

// Event handler for vehicle registration form submission
function handleRegisterSubmit(event) {
    event.preventDefault();

    // Get input values from the form
    const make = document.getElementById("vehicle-make").value;
    const model = document.getElementById("vehicle-model").value;
    const regNumber = document.getElementById("vehicle-regNum").value;

    // Register the vehicle
    registerVehicle(make, model, regNumber);
}

// Attach submit event listener to registration form
const registerForm = document.getElementById("register-form");
registerForm.addEventListener("submit", handleRegisterSubmit);

// Initial fetch of registered vehicles on page load
fetchVehicleData();
